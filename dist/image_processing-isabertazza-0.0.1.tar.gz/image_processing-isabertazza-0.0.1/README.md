# package_name_isabertazza

Description. 
The package package_name_isabertazza is used for:
	Processing:
		- Histogram matching
		- Structural similarity
		- Resize image

	Utils:
		- Read image
		- Save image
		- Plot image
		- Plot result
		- Plot histograms

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install package_name_isabertazza
```

<!-- ## Usage

```python
from package_name.module1_name import file1_name
file1_name.my_function()
``` -->

## Author
Isadora/Karina

## License
[MIT](https://choosealicense.com/licenses/mit/)